
import { useFormik } from "formik";
import { Form } from "react-bootstrap";
import { loginSchema } from "../../data/loginSchema";
import { getLoginFields } from "./loginConfig";
import InputProvider from "../../components/common/InputProvider";
import SocialLogins from "../../components/SocialLogins";
import { useNavigate, Link } from "react-router-dom";
import { PageContainer ,CardWrapper, FooterText, Title, Subtitle ,Stylelink} from "./styles"; 

import { useDispatch } from "react-redux";
import { login } from "../../store/auth/authSlice";

const LoginForm = () => {
  const navigate = useNavigate();
  const dispatch = useDispatch(); 

  const formik = useFormik({
    initialValues: {
      email: "",
      password: "",
      rememberMe: false,
    },
    validationSchema: loginSchema,
    onSubmit: (values) => {
      const userName = values.email ? values.email.split('@')[0] : "User";
      dispatch(login(userName));

      navigate("/LoginSuccessCard");
    },
  });

  const connectField = (name) => ({
    name,
    fieldValue: formik.values[name],
    onChangeFunction: (value) => formik.setFieldValue(name, value),
    onBlurFunction: () => formik.setFieldTouched(name, true),
    errorMessage: formik.touched[name] && formik.errors[name],
  });

  const fields = getLoginFields(connectField);

  return (
    <PageContainer>   
      <CardWrapper>
        <div className="card-top-border" />
        <Title>Welcome Back</Title>    
        <Subtitle>Sign in to your DKUST account</Subtitle>
    
        <Form onSubmit={formik.handleSubmit} noValidate>
          {fields.map((item) => (
            <InputProvider key={item.name} itemObject={item} />
          ))}

          <button className="submit-btn w-100" type="submit">
            SIGN IN
          </button>
        </Form>
      
        <SocialLogins />
        
        <FooterText className="mt-3">
          Don't have an account?{" "}
          <span className="sign-in" onClick={() => navigate("/register")} style={{ cursor: 'pointer' }}>
            Sign up
          </span>   
        </FooterText>
      </CardWrapper>
 <Stylelink>
        <Link to="/Home">Back to Home</Link>
      </Stylelink>
    </PageContainer>
  );
};

export default LoginForm;