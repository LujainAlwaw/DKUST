


import { useNavigate } from 'react-router-dom';
import { Container, Row, Col, Accordion } from 'react-bootstrap';
import 'bootstrap/dist/css/bootstrap.min.css';
import {
  PageWrapper,
  HeroSection,
  HeroTitle,
  HeroText,
  SectionHeader,
  StyledAccordionItem,
  CustomButton,
  BottomPromptText
} from './styles';

const HomeBootstrap = () => {
  const navigate = useNavigate();

  const handleGoToQuiz = () => {
    navigate('/QUIZ');
  };

  const faqData = [
    {
      id: "0",
      question: "What services do you offer?",
      answer: "We offer a wide range of technology services including web development, machine learning solutions, robotics engineering, industrial consulting, and data analytics."
    },
    {
      id: "1",
      question: "How can I contact your team?",
      answer: "You can reach our team through the contact form on our website, by emailing info@dkust.com, or by calling +1 234 567 8900."
    },
    {
      id: "2",
      question: "Do you provide technical support?",
      answer: "Yes, we provide comprehensive technical support for all our services, including standard email support and priority phone support."
    }
  ];

  return (
    <PageWrapper>
      <HeroSection>
        <Container>
          <Row className="justify-content-center">
            <Col lg={8}>
              <HeroTitle>Frequently Asked Questions</HeroTitle>
              <HeroText>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
              </HeroText>
              <CustomButton onClick={handleGoToQuiz}>
                ASK A QUESTION
              </CustomButton>
            </Col>
          </Row>
        </Container>
      </HeroSection>

      <Container className="py-5" style={{ maxWidth: '850px' }}>
        <SectionHeader>
          <h2>Generally Asked Question</h2>
          <p>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore.
          </p>
        </SectionHeader>

        <Accordion className="mb-5">
          {faqData.map((item) => (
            <Accordion.Item 
              eventKey={item.id} 
              key={item.id} 
              as={StyledAccordionItem}
            >
              <Accordion.Header>{item.question}</Accordion.Header>
              <Accordion.Body>{item.answer}</Accordion.Body>
            </Accordion.Item>
          ))}
        </Accordion>

        <div className="text-center mt-5">
          <BottomPromptText>Ready to test your knowledge?</BottomPromptText>
          <CustomButton onClick={handleGoToQuiz}>
            TAKE THE QUIZ
          </CustomButton>
        </div>
      </Container>
    </PageWrapper>
  );
};

export default HomeBootstrap;