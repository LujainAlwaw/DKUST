

import { useNavigate, Link } from 'react-router-dom';
import { FaCheck } from 'react-icons/fa';
import { PageContainer, SuccessWrapper, IconContainer, Title, Subtitle, ActionButton, Stylelink } from './styles';

import { useSelector } from 'react-redux';
import { selectUser } from '../../store/auth/authSelectors';
export default function LoginSuccessCard() {
  const navigate = useNavigate();
  
  const user = useSelector(selectUser);
  const displayName = user ? user.name : "User";

  return (
    <PageContainer>
      <SuccessWrapper>
        <div className="card-top-border" />

        <Title>Welcome Back, {displayName}</Title>
        <Subtitle>Sign in to your DKUST account</Subtitle>

        <IconContainer>
          <FaCheck />
        </IconContainer>

        <Title style={{ fontSize: '1.4rem', marginTop: '10px' }}>Login Successful!</Title>
        <Subtitle>
          You have been signed in successfully.
        </Subtitle>

        <ActionButton onClick={() => navigate("/home")}>
          Go to Home
        </ActionButton>
      </SuccessWrapper>

      <Stylelink>
        <Link to="/Home">Back to Home</Link>
      </Stylelink>
    </PageContainer>
  );
}