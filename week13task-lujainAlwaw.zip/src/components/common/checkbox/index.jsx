import { Form } from "react-bootstrap";
import { CheckboxStyles } from "./styles"; 

const CheckboxComponent = ({ itemObject, ...flatProps }) => {
  const {
    id,
    name,
    fieldLabel,
    fieldValue,
    onChangeFunction,
    onBlurFunction,
    errorMessage,
  } = itemObject ?? flatProps;

  return (
    <CheckboxStyles>
      <Form.Check
        type="checkbox"
        id={id || name}
        name={name}
        label={fieldLabel}
        checked={Boolean(fieldValue)}
        onChange={(e) => onChangeFunction?.(e.target.checked)}
        onBlur={() => onBlurFunction?.()}
      />
      {errorMessage && (
        <p className="field-error text-danger" style={{ fontSize: "12px", marginTop: "4px" }}>
          {errorMessage}
        </p>
      )}
    </CheckboxStyles>
  );
};

export default CheckboxComponent;