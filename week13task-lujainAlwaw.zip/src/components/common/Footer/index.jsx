import { FaPaperPlane } from 'react-icons/fa';
import {
  FooterContainer,
  FooterGrid,
  Column,
  NewsletterBox,
  BottomBar
} from './styles';

const Footer = () => {
  return (
    <FooterContainer>
      <FooterGrid>
        <Column>
          <h4>CONTACT DETAIL</h4>
          <p>123 Business Street, Suite 100<br />New York, NY 10001</p>
          <p>Phone: +1 234-567-890<br />Email: info@dkust.com</p>
        </Column>

        <Column>
          <h4>QUICK LINKS</h4>
          <a href="#about">About Us</a>
          <a href="#services">Services</a>
          <a href="#portfolio">Portfolio</a>
          <a href="#blog">Blog</a>
          <a href="#contact">Contact Us</a>
        </Column>

        <Column>
          <h4>OUR SERVICES</h4>
          <a href="#web">Web Development</a>
          <a href="#design">Frontend Development</a>
          <a href="#hosting">Web Hosting</a>
          <a href="#consulting">IT Consulting</a>
          <a href="#analytics">Data Analytics</a>
        </Column>

        <Column>
          <h4>SUBSCRIBE NEWSLETTER</h4>
          <p>Get the latest update and news.</p>
          <NewsletterBox>
            <input type="email" placeholder="Enter Fullname" />
            <button type="button">
              <FaPaperPlane size={12} />
            </button>
          </NewsletterBox>
        </Column>
      </FooterGrid>

      <BottomBar>
        Copyright &copy; 2026 DKUST. All Rights Reserved.
      </BottomBar>
    </FooterContainer>
  );
};

export default Footer;