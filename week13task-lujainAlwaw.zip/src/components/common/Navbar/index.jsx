


import { useState } from 'react';
import { FaBars, FaTimes, FaSun, FaMoon } from 'react-icons/fa';
import { NavLink } from 'react-router-dom';
import { useTheme } from '../../../context/theme/useTheme';
import {
  NavbarHeader, ContainerWrapper, Logo, MenuIcon,
  NavList, MobileHeader, StyledNavLink, ButtonGroup, NavBtn
} from './styles';

const navLinks = [
  { name: 'Home', path: '/HOME' },
  { name: 'About', path: '/ABOUT' },
  { name: 'Portfolio', path: '/PORTFOLIO' },
  { name: 'Products', path: '/Products' },
  { name: 'Services', path: '/SERVICES' },
  { name: 'Blog', path: '/BLOG' },
  { name: 'Resources', path: '/RESOURCES' },
  { name: 'Quiz', path: '/QUIZ' },
  { name: 'Contact', path: '/CONTACT' },
];

export default function Navbar() {
  const [isOpen, setIsOpen] = useState(false);
  const closeMenu = () => setIsOpen(false);

  const { darkMode, toggleDarkMode } = useTheme();

  return (
    <NavbarHeader>
      <ContainerWrapper>
        <Logo to="/HOME">DKUST</Logo>

        <MenuIcon onClick={() => setIsOpen(!isOpen)}>
          <FaBars />
        </MenuIcon>

        <NavList isOpen={isOpen}>
          <MobileHeader>
            <Logo to="/HOME" onClick={closeMenu}>DKUST</Logo>
            <MenuIcon onClick={closeMenu}>
              <FaTimes />
            </MenuIcon>
          </MobileHeader>

          {navLinks.map((link) => (
            <StyledNavLink key={link.name} to={link.path} onClick={closeMenu}>
              {link.name}
            </StyledNavLink>
          ))}

          <StyledNavLink to="/LOGEN" onClick={closeMenu} className="mobile-only">Login</StyledNavLink>
          <StyledNavLink to="/register" onClick={closeMenu} className="mobile-only">Register</StyledNavLink>
          
          <StyledNavLink 
            as="div" 
            onClick={toggleDarkMode} 
            className="mobile-only" 
            style={{ cursor: 'pointer' }}
          >
            {darkMode ? ' Light Mode' : ' Dark Mode'}
          </StyledNavLink>
        </NavList>

        <ButtonGroup>
          <NavLink to="/LOGEN"><NavBtn>LOGIN</NavBtn></NavLink>
          <NavLink to="/register"><NavBtn>REGISTER</NavBtn></NavLink>
          
          <NavBtn onClick={toggleDarkMode} title="Toggle Dark/Light Mode">
            {darkMode ? <FaSun size={14} /> : <FaMoon size={14} />}
          </NavBtn>
        </ButtonGroup>
      </ContainerWrapper>
    </NavbarHeader>
  );
}