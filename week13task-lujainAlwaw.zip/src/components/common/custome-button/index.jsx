


import { useState } from 'react';
import { AiOutlineEye, AiOutlineEyeInvisible } from 'react-icons/ai';
import { InputGroup, Label, StyledInput, ErrorText, PasswordWrapper, EyeIcon } from './styles';

export default function InputField({ itemObject, ...flatProps }) {
  const {
    type = 'text',
    name,
    fieldLabel,
    placeholder,
    fieldValue,
    onChangeFunction,
    onBlurFunction,
    errorMessage,
    halfWidth,
  } = itemObject ?? flatProps;

  const [showPassword, setShowPassword] = useState(false);
  const isPasswordType = type === 'password';
  const inputType = isPasswordType ? (showPassword ? 'text' : 'password') : type;

  return (
    <InputGroup halfWidth={halfWidth}>
      {fieldLabel && <Label>{fieldLabel}</Label>}
      
      <PasswordWrapper>
        <StyledInput
          type={inputType}
          name={name}
          placeholder={placeholder}
          value={fieldValue || ''}
          onChange={(e) => onChangeFunction?.(e.target.value)}
          onBlur={() => onBlurFunction?.()}
          isError={Boolean(errorMessage)}
        />
        
        {isPasswordType && (
          <EyeIcon onClick={() => setShowPassword(!showPassword)}>
            {showPassword ? <AiOutlineEyeInvisible /> : <AiOutlineEye />}
          </EyeIcon>
        )}
      </PasswordWrapper>

      {errorMessage && <ErrorText>{errorMessage}</ErrorText>}
    </InputGroup>
  );
}