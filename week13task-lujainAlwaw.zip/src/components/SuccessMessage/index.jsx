import { useNavigate, Link } from 'react-router-dom';
import { FaCheck } from 'react-icons/fa';
import{SuccessWrapper,IconContainer,Title,Subtitle,ActionButton,Stylelink,PageContainer }from "./styles"
export default function SuccessCard({ userName = "User" }) {
  const navigate = useNavigate();

  return (
    <PageContainer>
    <div className="container d-flex flex-column justify-content-center align-items-center min-vh-100">
      <SuccessWrapper>
        <div className="card-top-border" />
        
        <IconContainer>
          <FaCheck />
        </IconContainer>

        <Title>Account Created!</Title>
        <Subtitle>
          Welcome, {userName}! Your account has been created successfully.
        </Subtitle>

        <ActionButton onClick={() => navigate("/LOGEN")}>
          Go to Login
        </ActionButton>
      </SuccessWrapper>

      <Stylelink >
        <Link to="/Home">
          Back to Home
        </Link>
      </Stylelink>
    </div>
    </PageContainer>
  );
}
