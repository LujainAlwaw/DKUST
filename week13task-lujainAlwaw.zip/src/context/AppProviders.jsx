

import { ThemeProvider } from "./theme/ThemeProvider";

export const AppProviders = ({ children }) => {
  return (
    <ThemeProvider>
      {children}
    </ThemeProvider>
  );
};