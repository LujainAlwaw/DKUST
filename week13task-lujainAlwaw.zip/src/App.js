
import './assets/styles/index.css';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
 import { AppProviders } from './context/AppProviders'; 
import Navbar from './components/common/Navbar';
import Footer from './components/common/Footer';
import Login from './Pages/LOGEN';
import Register from './Pages/REGISTER';

import ProductsPage from './Pages/Products';
import Quiz from './Pages/QUIZ';
import ProductDetails from './Pages/productDetails';
import Home from './Pages/Home';
import SuccessCard from './components/SuccessMessage';
import LoginSuccessCard from './components/LoginSuccess';

import { Provider } from 'react-redux';
import { store } from './store';

function App() {
  return (
    <Provider store={store}>
      <BrowserRouter>
        <AppProviders>
         <Navbar />
        <Routes>
         <Route path="/Home" element={<Home />} />
          <Route path="/REGISTER" element={<Register />} />
         <Route path="/LOGEN" element={<Login />} />
          <Route path="/Products" element={<ProductsPage />} />   
                 <Route path="/QUIZ" element={<Quiz />} />
           <Route path="/SuccessMessage" element={<SuccessCard />} />
          <Route path="/LoginSuccessCard" element={<LoginSuccessCard />} />
                    <Route path="/products/:id" element={<ProductDetails />} />
          <Route path="*" element={<h2>Page Not Found</h2>} />
       </Routes>
        <Footer />
        </AppProviders>
      </BrowserRouter>
    </Provider>
  );
}

export default App;